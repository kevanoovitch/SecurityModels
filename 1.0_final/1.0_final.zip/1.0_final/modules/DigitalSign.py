# ==============================================================================
# Author: Ludwig Sterner
# Email: luse23@student.bth.se
#
# Author: Kevin Deshayes
# Email: kede23@student.bth.se
# ==============================================================================
from modules.file_traversal import file_traversal
import gnupg
import os
gpg = gnupg.GPG()


def criticalFiles():
    # Gets the parent dir
    current_dir = os.path.dirname(os.path.realpath(__file__))
    parent_dir = os.path.abspath(os.path.join(current_dir, os.pardir))
    criticalfiles_dir = parent_dir

    criticalFiles = file_traversal(criticalfiles_dir)

    # filter out '/directory'
    criticalFiles = [
        file for file in criticalFiles if 'assets/directory' not in file]

    # filter out python cache
    criticalFiles = [
        file for file in criticalFiles if 'modules/__pycache__' not in file]

    # filter out the log file
    criticalFiles = [
        file for file in criticalFiles if 'dv1667.log' not in file]

    # filter out .DS_Store files
    criticalFiles = [
        file for file in criticalFiles if not file.endswith('.DS_Store')]

    # filter out existing file signatures
    criticalFiles = [
        file for file in criticalFiles if 'assets/FileSignatures' not in file]

    return criticalFiles
# 1. sign all files (and put in a directory)
# ============================


signatures_dir = "assets/FileSignatures"


def sign_files(email):
    gpg = gnupg.GPG()

    # Checks that signatures directory exists
    os.makedirs(signatures_dir, exist_ok=True)
    if os.listdir(signatures_dir):  # Checks if the directory is not empty
        print("The signatures directory is not empty. Not resigning files")
        return

    for file_path in criticalFiles():
        with open(file_path, 'rb') as f:
            # Sign the file
            signed_data = gpg.sign_file(f, keyid=email, detach=True)

            # Construct the path for the signature file within the specified directory
            base_name = os.path.basename(file_path)
            sig_path = os.path.join(signatures_dir, f"{base_name}.sig")

            # Save the signature to the .sig file in the specified directory
            with open(sig_path, 'wb') as sig_file:
                sig_file.write(str(signed_data).encode('utf-8'))


# 2. verify files
# ==========================


def SignVerification():

    flag = False

    log = open("dv1667.log", "a")

    for file_path in criticalFiles():
        base_name = os.path.basename(file_path)
        signature_path = os.path.join(signatures_dir, base_name + '.sig')

        with open(signature_path, 'rb') as sig_file:
            verification = gpg.verify_file(sig_file, file_path)

            if os.path.exists(file_path) == False:
                log.write(f"File does not exist {file_path} \n")

            if verification and verification.valid:
                log.write(f"Signature is valid for {file_path}\n")
            else:
                flag = True
                log.write(
                    f"Verification failed or signature not valid for {file_path}\n")

    log.close()
    if flag is True:
        return print("!!! FILE INTEGRITY COMPROMISED !!!" + "\n Check log file for details")
